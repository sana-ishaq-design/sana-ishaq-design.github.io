---
name: Strategic Authority
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#271901'
  on-tertiary-container: '#98805d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#fcdeb5'
  tertiary-fixed-dim: '#dec29a'
  on-tertiary-fixed: '#271901'
  on-tertiary-fixed-variant: '#574425'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 32px
  margin-desktop: 64px
  margin-mobile: 20px
  stack-lg: 80px
  stack-md: 40px
  stack-sm: 24px
---

## Brand & Style
The design system is engineered to project a persona of high-level strategic thinking and precision-driven execution. It targets executive stakeholders and product leaders who value data-backed design over fleeting trends. 

The aesthetic is **Corporate Modern with a Minimalist edge**, prioritizing clarity and "breathing room" to reflect the confidence of a senior practitioner. It avoids decorative clutter, ensuring every element serves a functional or communicative purpose. The emotional response should be one of immediate trust, professional stability, and high-value expertise.

## Colors
The palette is anchored by **Deep Midnight Blue (#0F172A)**, used for primary surfaces, headings, and high-authority elements to establish immediate professional gravity. 

**Success Green (#10B981)** is reserved strictly for conversion-oriented accents, success states, and metric-driven data visualizations, creating a clear semantic link between the design and positive business outcomes. 

The background environment utilizes **Clean White (#FFFFFF)** and ultra-light cool greys to maintain a high-contrast, airy atmosphere that emphasizes readability and "premium" whitespace.

## Typography
This design system utilizes **Inter** exclusively to leverage its systematic, neutral, and highly legible characteristics. The typographic hierarchy is strictly enforced to guide the viewer through complex strategic narratives.

Headlines use tighter letter-spacing and heavier weights to feel "locked-in" and authoritative. Body text uses generous line-height (1.5x minimum) to ensure long-form case studies remain accessible. Labels are occasionally set in uppercase with slight tracking to differentiate them from prose.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to maintain a controlled, editorial feel. A 12-column grid is utilized with wide 32px gutters to prevent content density from feeling overwhelming.

Spacing is governed by an 8px base unit, but "generosity" is the primary directive. Vertical sections should be separated by significant padding (`stack-lg`) to allow the user to process one strategic thought at a time. On mobile, margins shrink to 20px, and the grid collapses to a single-column flow, maintaining the same vertical breathing room.

## Elevation & Depth
Depth is communicated through **Tonal Layers** and **Low-Contrast Outlines** rather than heavy shadows. This maintains the "Flat-Plus" professional aesthetic.

- **Level 0 (Surface):** Pure white (#FFFFFF) for the main canvas.
- **Level 1 (Card/Section):** Subtle light-grey background (#F8FAFC) or a 1px border (#E2E8F0).
- **Interactive States:** A very soft, highly diffused ambient shadow (10% opacity of the Primary color) may be used on hover to indicate tactility without breaking the clean aesthetic.
- **Overlays:** Modals use a 40% opacity blur of the Midnight Blue to maintain brand presence even when focusing the user.

## Shapes
The shape language is **Soft (0.25rem)**. This subtle rounding removes the aggressive "sharpness" of pure brutalism while remaining far more professional and structured than pill-shaped consumer apps. 

Containers use `rounded-lg` (0.5rem) to provide a gentle frame for content, while smaller components like checkboxes and small buttons stay at the base 0.25rem to maintain a sense of precision and "architectural" alignment.

## Components
- **Buttons:** Primary buttons are solid Deep Midnight Blue with white text. Success actions use the Success Green. Buttons are rectangular with a 4px (Soft) radius. Padding is generous: 12px 24px for standard.
- **Input Fields:** Use a 1px border (#E2E8F0). Focus states transition the border to Deep Midnight Blue with a subtle 2px outer glow.
- **Cards:** White background with a 1px #E2E8F0 border. No shadow in the default state. Headings within cards should be primary blue, while supporting text is secondary slate.
- **Chips/Badges:** Use Success Green at 10% opacity with 100% opacity green text for "Results" or "Metrics."
- **Lists:** Unordered lists use custom "check" icons in Success Green instead of standard bullets to reinforce the "Results-Oriented" theme.
- **Data Callouts:** Large numeric displays (e.g., " +24% Conversion") should use the Success Green and the `display-lg` typographic style to draw immediate attention.